<?php
session_start();
require 'config.php';

if (!isset($_SESSION['id_employe'])) {
    header('Location: login_employe.php');
    exit();
}

$id_employe = $_SESSION['id_employe'];

// Récupérer les notifications
$notifications = $conn->query("SELECT id_employe, message, vu FROM notifications WHERE matricule = (SELECT matricule FROM employes WHERE id_employe = $id_employe)")->fetchAll(PDO::FETCH_ASSOC);

// Marquer comme lues
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->query("UPDATE notifications SET vu = 1 WHERE matricule = (SELECT matricule FROM employes WHERE id_employe = $id_employe)");
    header('Location: page_notification_employe.php');
    exit();
}

?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body class="dark-theme">
    <style>
        body.dark-theme {
            background-color: #2c2c54;
            /* Couleur de fond sombre */
            color: #ffffff;
            /* Couleur du texte */
            font-family: Arial, sans-serif;
            /* Police de base */
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #ffffff;
            /* Couleur du titre */
        }

        .notification-list {
            list-style-type: none;
            /* Supprime les puces de la liste */
            padding: 0;
            /* Supprime le padding par défaut */
        }

        .notification-list li {
            padding: 10px;
            border-radius: 5px;
            /* Coins arrondis */
            margin-bottom: 10px;
            /* Espacement entre les notifications */
            transition: background-color 0.3s;
            /* Transition pour l'effet hover */
        }

        .notification-list li.unread {
            background-color: darkmagenta;
            /* Couleur de fond pour les notifications non lues */
            color: #ffffff;
            /* Couleur du texte pour les notifications non lues */
        }

        .notification-list li.read {
            background-color: darkorchid;
            /* Couleur de fond pour les notifications lues */
            color: #cccccc;
            /* Couleur du texte pour les notifications lues */
        }

        .mark-read-btn {
            background-color: #ff4757;
            /* Couleur de fond du bouton */
            color: #ffffff;
            /* Couleur du texte du bouton */
            border: none;
            /* Pas de bordure */
            border-radius: 5px;
            /* Coins arrondis */
            padding: 10px 15px;
            /* Espacement interne */
            cursor: pointer;
            /* Curseur pointer */
            transition: background-color 0.3s;
            /* Transition pour l'effet hover */
        }

        .mark-read-btn:hover {
            background-color: #e84118;
            /* Couleur de fond au survol */
        }
    </style>
    <h1>Notifications</h1>

    <?php if (!empty($notifications)): ?>
        <ul class="notification-list">
            <?php foreach ($notifications as $notif): ?>
                <li class="<?= $notif['vu'] ? 'read' : 'unread' ?>">
                    <?= htmlspecialchars($notif['message']) ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <form method="POST">
            <button type="submit" class="mark-read-btn">Marquer comme lues</button>
        </form>
    <?php else: ?>
        <p>Aucune notification.</p>
    <?php endif; ?>

</body>

</html>